# SolderShape recorded Board example

Status: hypothetical process inputs; physical force accuracy unqualified.
Only U1/J16 is computed. The ULX3S board supplies context.

The inner board-comparison.zip is the unchanged native evidence archive.
Its SHA-256 is b6bf18f68ce868fa1a1cd1151be0360f1c7d20667b25154d569af1a825e16d64.
Open review.html for exact values. For its evidence links, extract the inner ZIP
and open the review.html inside that extracted folder. The outer review is a convenience copy.

From a SolderShape source checkout with the pinned engine installed, replay the inner ZIP:
python3 tools/verify_board.py /path/to/board-comparison.zip --replay

The outer manifest hashes every member. The inner manifest remains unchanged.
Neither is an independent signature or physical validation.

ULX3S is by EMARD and its contributors; retain BOARD-LICENSE.md and its logo terms.
Numerical computation and BGA methods are Ken Brakke's Surface Evolver work.
Original SolderShape code and documentation use PROJECT-LICENSE.txt.
Third-party material retains its own terms in THIRD_PARTY.md.
This is not a board or fixture fabrication release.
