# SolderShape recorded Board walkthrough

These are hypothetical process inputs at the actual ULX3S U1/J16 copper pad.
Only the selected isolated joint is computed. Physical force accuracy remains unqualified.
The paired scenarios change only the held wetted-plane gap, from 300 to 330 µm.
Each scenario compares 40 and 56 nL at 240 µm offset on 400 µm circular pads.

Open gap-300/review.html and gap-330/review.html for the exact conditional results.
Each folder also contains the unchanged original board-comparison.zip and exact extracted members.
From a source checkout, replace /path/to/package with the extracted wrapper directory
and verify each original archive with the trusted verifier:

    python3 tools/verify_board.py /path/to/package/gap-300/board-comparison.zip
    python3 tools/verify_board.py /path/to/package/gap-330/board-comparison.zip

Add --replay after installing the pinned native engine to repeat the calculations.
Numerical replay does not establish physical accuracy, production approval or manufacturing yield.
The outer manifest hashes every other member. Inner archive bytes and manifests remain unchanged.
These hashes provide local integrity checks, not an independent signature.

ULX3S is by EMARD and its contributors. Retain BOARD-LICENSE.md and its logo terms.
Numerical computation and BGA methods are Ken Brakke's Surface Evolver work.
Original SolderShape code and documentation use PROJECT-LICENSE.txt.
Third-party material retains its own terms in THIRD_PARTY.md and KICAD-LICENSE.md.
This is not a board or fixture fabrication release.
