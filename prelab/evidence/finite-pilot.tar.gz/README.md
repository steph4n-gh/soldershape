# Prescribed-wetting finite-copper pilot

`summary.json` accounts for 28 isolated calculation jobs and their retained failures. Its interpretation is conditional on declared sidewall wetting. Nothing here is physically validated.

The adapter is `prelab/finite.py`. It runs each native calculation in an isolated Python process. `soldershape/model.py` and `soldershape/solver.py` remain byte-identical to commit `33666d32c92b6753925bb2fd29dc62ce5fed618b`. Each receipt records those identities and the engine identity. Raw model, commands and native logs are retained. Adapter snapshots hash-match every historical receipt. The earlier adapter source snapshots were reconstructed by reversing recorded edits and then checked against their originally recorded SHA-256 values.

## Nominal results

At the declared original heights, C220 and C270 fixed-gap calculations pass unchanged native gates under zero wetting and full 35 micrometer sidewall wetting. Full-wetting reactions from fresh relaxed energies agree with the prescribed 6.864655 micronewton load. Using both displacement steps of 0.5 and 0.25 micrometers and the last two refinement levels gives maximum residuals of 0.002485 micronewtons for C220 and 0.003471 micronewtons for C270. The numerical engineering tolerance is 0.01 micronewtons. This is numerical agreement, not a physical error budget.

The current C220 full-wetting loaded calculation predicts 178.203436202 micrometers. Its archived cylinder mapping predicted 178.203381224 micrometers. The difference is 0.000054978 micrometers. Both have inactive obstacles and pass sampled curved-interface clearance. This verifies implementation under one prescribed boundary. It does not establish that this is the observed wetting state.

The C270 native optimizing-height calculation fails active-set mechanics. Its nominal fixed-gap calculation and fresh relaxed-energy load balance succeed. This distinguishes an optimizer failure from physical infeasibility. This pilot does not qualify a replacement loaded rootfinder.

## Negative control and limitations

A deliberately reduced liquid volume of 0.008 cubic millimeters at an envelope height of 0.25 millimeters produces 7.616 micrometers of sampled copper intrusion without obstacles. With obstacles, the native solution remains not converged, creates new wall contact and retains up to 2.461 micrometers of curved-facet intrusion. It is rejected. Vertex constraints do not imply continuous quadratic-facet exclusion. Missing wetting energy also precludes physical interpretation of new wall contact.

Nominal C270 full wetting initially fails the sampling tolerance because the quadratic approximation to a prescribed circular rim deviates by less than one nanometer. A separately retained extra refinement passes the original tolerance. No tolerance was relaxed. All other original stationarity, volume, force-refinement, Hessian, timeout and native mesh limits are retained. The additional curved-interface text has its own bounded eight-megabyte limit.

The diagnostic samples 15 barycentric points per exported curved liquid-air facet before flattening. It excludes zero-tension volume caps. It reports every solid-residual minimum. Prescribed rim contact is identified from its boundary topology rather than treating circular interpolation error as new wall contact. Finite samples do not certify continuous clearance.

Gravity is disabled. The envelope includes exact cylinder-volume additions for the prescribed depths. No unknown sidewall contact angle or hysteresis parameter is fitted. The experiment cannot identify real wetting depth or predict hot-to-cold contraction. Those observations still require the lab.

## Reproduce

Run `python3 -m unittest prelab.test_finite -v` from the project root. Seven focused tests pass, including a linear-energy control for reaction units and sign. Native requests are stored in every calculation directory's `request.json`. A native replay can be run in a fresh empty directory by copying its request and invoking `python3 -m prelab.finite --worker /absolute/path/to/fresh/directory`. The current adapter is separate from historical snapshot versions. Always compare the adapter hash as well as the request.

The public helper `fixed_energy_check` performs fresh fixed-gap minimizations at both displacement steps. When started with `level_count=2`, it also runs level 3. The completed full-wetting pilots explicitly used level 3 after nominal level-2 controls and retain reactions from all three internal refinements. The machine summary independently recomputes reactions at the final two refinements from the saved native energies.
